#include <stdio.h>
#include <stdlib.h>

int
main(void)
{
    (void)printf("Hello World!\n\n");
    (void)printf("I know him well.\n");
    (void)printf("He is the broach indeed\n");
    (void)printf("And gem of all the nation.\n");
    return EXIT_SUCCESS;
}
